(function(document, window, $, undefined){
	'use strict';
	//jquery method:

}(document, window, jQuery, undefined));