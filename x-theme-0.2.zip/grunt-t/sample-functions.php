<?php 

//#1 To add styleseet version number

function custom_css_version($styles){
	$styles->default_version = "4.4.5";
}
add_action("wp_default_styles", "custom_css_version");

//#2 Change the Default Gravatar in WordPress

add_filter( 'avatar_defaults', 'new_gravatar' );

function new_gravatar ($avatar_defaults) {
$my_avatar = get_bloginfo('template_directory') . '/images/gravatar.gif';
$avatar_defaults[$my_avatar] = "X-Theme";
return $avatar_defaults;
}

//#3 Register Sidebar Widgets

if(function_exists('register_sidebar')){
	register_sidebar(array(
		'name' => 'my_custom_sidebar',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	));
}
// display the sidebar in your theme, //

if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('my_custom_sidebar') ) :endif;

//#4 Custom Excerpt Length

function new_excerpt_length($length) {
	return 25;
}
add_filter('excerpt_length', 'new_excerpt_length');