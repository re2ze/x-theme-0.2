<div>
	<?php dynamic_sidebar( 'primary' ); ?>
</div>