<?php

/**
 ** X-Theme functions and definitions
 **
 ** When using a child theme (see http://codex.wordpress.org/Theme_Development and
 ** http://codex.wordpress.org/Child_Themes), you can override certain functions
 ** (those wrapped in a function_exists()) by defining them first in your child theme's
 ** functions.php file. The child theme's functions.php file is included before the parent
 ** theme's file, so the child theme functions would be used.
 **
 ** @package X-Theme
 ** @since 1.0.0
 **/
/**
 ** Custom utility functions that required for the theme.
 ** after u can use x_theme_get_theme_v(), 
 **/
require get_template_directory() . '/includes/helper.php';

function x_theme_enqueue_scripts() {

	wp_enqueue_style( 'x-theme-style', get_template_directory_uri() . '/assets/public/css/app.css', array() );
	
	wp_enqueue_script( 'x-theme-script', get_template_directory_uri() . '/assets/public/js/app' . x_theme_script_prefix() . '.js' , array('jquery'), x_theme_get_theme_v(), true );

}

add_action( 'wp_enqueue_scripts', 'x_theme_enqueue_scripts' );